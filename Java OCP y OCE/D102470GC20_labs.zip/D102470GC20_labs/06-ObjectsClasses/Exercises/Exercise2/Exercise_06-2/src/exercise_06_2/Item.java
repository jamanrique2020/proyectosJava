/* Copyright © 2018 Oracle and/or its affiliates. All rights reserved. */

package exercise_06_2;

public class Item {
        public int itemID;
        public String desc;
        public double price;
        public int quantity;
}
