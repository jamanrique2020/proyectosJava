/* Copyright © 2018 Oracle and/or its affiliates. All rights reserved. */

package exercise;

public class ShoppingCart {
    public static void main(String[] args){
        System.out.println("Welcome to the Shopping Cart!");
    }
}
