Exercise 5-3

1. Create a for loop that iterates through the items array,
     displaying each element. Precede the list of elements with 
     the message, "Items purchased: ".
