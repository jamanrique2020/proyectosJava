/* Copyright © 2018 Oracle and/or its affiliates. All rights reserved. */

package exercise_05_2;

public class ShoppingCart {
    public static void main(String[] args){
        String custName = "Mary Smith";
        String message = custName + " wants to purchase several items.";
 
        // Declare and initialize the items String array with 4 item descriptions.
        
        // Change message to show the number of items purchased.
        
        System.out.println(message);
        // Print an element from the items array.
        
    }
}
