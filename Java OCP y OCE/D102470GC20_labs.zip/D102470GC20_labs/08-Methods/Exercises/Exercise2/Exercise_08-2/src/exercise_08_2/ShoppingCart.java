/* Copyright © 2016 Oracle and/or its affiliates. All rights reserved. */

package exercise_08_2;

public class ShoppingCart {
    public static void main (String[] args){
        Item item1 = new Item();
        
        // Call the 3-arg setItemFields method and then call displayItem.

        // Call the 4-arg setItemFields method, checking the return value.

    } 
}
