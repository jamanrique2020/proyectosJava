/* Copyright © 2016 Oracle and/or its affiliates. All rights reserved. */

package exercise_09_1;

public class Customer {
    public String name;
    public String ssn;
   
    // Encapsulate this class.  Make ssn read only.

}
