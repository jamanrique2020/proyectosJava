/* Copyright © 2016 Oracle and/or its affiliates. All rights reserved. */

package exercise_09_2;

public class ShoppingCart {
    public static void main(String[] args) {
        // Declare, instantiate, and initialize a Customer object.
        
        // Print the customer object name.
        
    }    
}
